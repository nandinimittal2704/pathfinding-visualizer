import pygame
import sys
from collections import deque
import heapq
import math
from enum import Enum
from typing import List, Tuple, Optional, Set

# Initialize Pygame
pygame.init()

# Constants
WINDOW_WIDTH = 1000
WINDOW_HEIGHT = 700
GRID_WIDTH = 800
GRID_HEIGHT = 600
GRID_ROWS = 30
GRID_COLS = 40
CELL_SIZE = GRID_WIDTH // GRID_COLS

# Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GREEN = (0, 255, 0)
RED = (255, 0, 0)
BLUE = (0, 0, 255)
LIGHT_BLUE = (173, 216, 230)
YELLOW = (255, 255, 0)
GRAY = (128, 128, 128)
DARK_GRAY = (64, 64, 64)
PURPLE = (128, 0, 128)

class CellType(Enum):
    EMPTY = 0
    START = 1
    END = 2
    OBSTACLE = 3
    VISITED = 4
    PATH = 5

class Algorithm(Enum):
    BFS = "BFS"
    DFS = "DFS"
    DIJKSTRA = "Dijkstra"
    ASTAR = "A*"

class Node:
    def __init__(self, row: int, col: int):
        self.row = row
        self.col = col
        self.g_cost = float('inf')  # Distance from start
        self.h_cost = 0  # Heuristic distance to end
        self.f_cost = float('inf')  # Total cost
        self.parent = None
        self.cell_type = CellType.EMPTY
    
    def __lt__(self, other):
        return self.f_cost < other.f_cost
    
    def reset(self):
        """Reset node to empty state"""
        if self.cell_type not in [CellType.START, CellType.END, CellType.OBSTACLE]:
            self.cell_type = CellType.EMPTY
        self.g_cost = float('inf')
        self.h_cost = 0
        self.f_cost = float('inf')
        self.parent = None

class PathfindingVisualizer:
    def __init__(self):
        self.screen = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
        pygame.display.set_caption("Pathfinding Algorithm Visualizer")
        self.clock = pygame.time.Clock()
        
        # Initialize grid
        self.grid = [[Node(row, col) for col in range(GRID_COLS)] for row in range(GRID_ROWS)]
        
        # State variables
        self.start_node = None
        self.end_node = None
        self.current_algorithm = Algorithm.BFS
        self.is_running = False
        self.visualization_speed = 50  # milliseconds between steps
        
        # UI elements
        self.font = pygame.font.Font(None, 24)
        self.small_font = pygame.font.Font(None, 18)
        
        # Button definitions
        self.buttons = {
            'BFS': pygame.Rect(820, 50, 80, 30),
            'DFS': pygame.Rect(910, 50, 80, 30),
            'Dijkstra': pygame.Rect(820, 90, 80, 30),
            'A*': pygame.Rect(910, 90, 80, 30),
            'Start': pygame.Rect(820, 150, 80, 30),
            'Clear': pygame.Rect(910, 150, 80, 30),
            'Reset': pygame.Rect(865, 190, 80, 30)
        }
    
    def get_neighbors(self, node: Node) -> List[Node]:
        """Get valid neighboring nodes"""
        neighbors = []
        directions = [(0, 1), (1, 0), (0, -1), (-1, 0)]  # Right, Down, Left, Up
        
        for dr, dc in directions:
            new_row, new_col = node.row + dr, node.col + dc
            
            if (0 <= new_row < GRID_ROWS and 0 <= new_col < GRID_COLS and 
                self.grid[new_row][new_col].cell_type != CellType.OBSTACLE):
                neighbors.append(self.grid[new_row][new_col])
        
        return neighbors
    
    def heuristic(self, node1: Node, node2: Node) -> float:
        """Calculate Manhattan distance heuristic"""
        return abs(node1.row - node2.row) + abs(node1.col - node2.col)
    
    def reconstruct_path(self, end_node: Node) -> List[Node]:
        """Reconstruct path from end to start"""
        path = []
        current = end_node
        
        while current is not None:
            if current.cell_type not in [CellType.START, CellType.END]:
                current.cell_type = CellType.PATH
            path.append(current)
            current = current.parent
        
        return path[::-1]
    
    def bfs(self) -> bool:
        """Breadth-First Search algorithm"""
        if not self.start_node or not self.end_node:
            return False
        
        queue = deque([self.start_node])
        visited = set()
        visited.add((self.start_node.row, self.start_node.col))
        
        while queue:
            current = queue.popleft()
            
            if current == self.end_node:
                self.reconstruct_path(current)
                return True
            
            for neighbor in self.get_neighbors(current):
                if (neighbor.row, neighbor.col) not in visited:
                    visited.add((neighbor.row, neighbor.col))
                    neighbor.parent = current
                    
                    if neighbor.cell_type == CellType.EMPTY:
                        neighbor.cell_type = CellType.VISITED
                    
                    queue.append(neighbor)
            
            # Visualization delay
            self.draw()
            pygame.time.wait(self.visualization_speed)
            
            # Handle events during visualization
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    return False
        
        return False
    
    def dfs(self) -> bool:
        """Depth-First Search algorithm"""
        if not self.start_node or not self.end_node:
            return False
        
        stack = [self.start_node]
        visited = set()
        
        while stack:
            current = stack.pop()
            
            if (current.row, current.col) in visited:
                continue
            
            visited.add((current.row, current.col))
            
            if current == self.end_node:
                self.reconstruct_path(current)
                return True
            
            if current.cell_type == CellType.EMPTY:
                current.cell_type = CellType.VISITED
            
            for neighbor in self.get_neighbors(current):
                if (neighbor.row, neighbor.col) not in visited:
                    neighbor.parent = current
                    stack.append(neighbor)
            
            # Visualization delay
            self.draw()
            pygame.time.wait(self.visualization_speed)
            
            # Handle events during visualization
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    return False
        
        return False
    
    def dijkstra(self) -> bool:
        """Dijkstra's algorithm"""
        if not self.start_node or not self.end_node:
            return False
        
        # Initialize distances
        self.start_node.g_cost = 0
        heap = [self.start_node]
        visited = set()
        
        while heap:
            current = heapq.heappop(heap)
            
            if (current.row, current.col) in visited:
                continue
            
            visited.add((current.row, current.col))
            
            if current == self.end_node:
                self.reconstruct_path(current)
                return True
            
            if current.cell_type == CellType.EMPTY:
                current.cell_type = CellType.VISITED
            
            for neighbor in self.get_neighbors(current):
                if (neighbor.row, neighbor.col) not in visited:
                    new_distance = current.g_cost + 1
                    
                    if new_distance < neighbor.g_cost:
                        neighbor.g_cost = new_distance
                        neighbor.f_cost = new_distance
                        neighbor.parent = current
                        heapq.heappush(heap, neighbor)
            
            # Visualization delay
            self.draw()
            pygame.time.wait(self.visualization_speed)
            
            # Handle events during visualization
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    return False
        
        return False
    
    def astar(self) -> bool:
        """A* algorithm"""
        if not self.start_node or not self.end_node:
            return False
        
        # Initialize start node
        self.start_node.g_cost = 0
        self.start_node.h_cost = self.heuristic(self.start_node, self.end_node)
        self.start_node.f_cost = self.start_node.h_cost
        
        open_set = [self.start_node]
        closed_set = set()
        
        while open_set:
            current = heapq.heappop(open_set)
            
            if (current.row, current.col) in closed_set:
                continue
            
            closed_set.add((current.row, current.col))
            
            if current == self.end_node:
                self.reconstruct_path(current)
                return True
            
            if current.cell_type == CellType.EMPTY:
                current.cell_type = CellType.VISITED
            
            for neighbor in self.get_neighbors(current):
                if (neighbor.row, neighbor.col) in closed_set:
                    continue
                
                tentative_g = current.g_cost + 1
                
                if tentative_g < neighbor.g_cost:
                    neighbor.parent = current
                    neighbor.g_cost = tentative_g
                    neighbor.h_cost = self.heuristic(neighbor, self.end_node)
                    neighbor.f_cost = neighbor.g_cost + neighbor.h_cost
                    
                    heapq.heappush(open_set, neighbor)
            
            # Visualization delay
            self.draw()
            pygame.time.wait(self.visualization_speed)
            
            # Handle events during visualization
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    return False
        
        return False
    
    def run_algorithm(self):
        """Run the selected pathfinding algorithm"""
        if self.is_running:
            return
        
        self.is_running = True
        self.clear_path()
        
        success = False
        if self.current_algorithm == Algorithm.BFS:
            success = self.bfs()
        elif self.current_algorithm == Algorithm.DFS:
            success = self.dfs()
        elif self.current_algorithm == Algorithm.DIJKSTRA:
            success = self.dijkstra()
        elif self.current_algorithm == Algorithm.ASTAR:
            success = self.astar()
        
        if not success:
            print(f"No path found using {self.current_algorithm.value}")
        
        self.is_running = False
    
    def clear_path(self):
        """Clear visited nodes and path, keep start, end, and obstacles"""
        for row in self.grid:
            for node in row:
                node.reset()
    
    def clear_all(self):
        """Clear everything including start, end, and obstacles"""
        for row in self.grid:
            for node in row:
                node.cell_type = CellType.EMPTY
                node.reset()
        
        self.start_node = None
        self.end_node = None
    
    def get_cell_color(self, cell_type: CellType) -> Tuple[int, int, int]:
        """Get color for cell type"""
        color_map = {
            CellType.EMPTY: WHITE,
            CellType.START: GREEN,
            CellType.END: RED,
            CellType.OBSTACLE: BLACK,
            CellType.VISITED: LIGHT_BLUE,
            CellType.PATH: YELLOW
        }
        return color_map.get(cell_type, WHITE)
    
    def draw_grid(self):
        """Draw the grid and cells"""
        for row in range(GRID_ROWS):
            for col in range(GRID_COLS):
                node = self.grid[row][col]
                color = self.get_cell_color(node.cell_type)
                
                rect = pygame.Rect(col * CELL_SIZE, row * CELL_SIZE, CELL_SIZE, CELL_SIZE)
                pygame.draw.rect(self.screen, color, rect)
                pygame.draw.rect(self.screen, GRAY, rect, 1)
    
    def draw_ui(self):
        """Draw user interface elements"""
        # Draw control panel background
        panel_rect = pygame.Rect(GRID_WIDTH, 0, WINDOW_WIDTH - GRID_WIDTH, WINDOW_HEIGHT)
        pygame.draw.rect(self.screen, DARK_GRAY, panel_rect)
        
        # Draw title
        title = self.font.render("Pathfinding Visualizer", True, WHITE)
        self.screen.blit(title, (820, 10))
        
        # Draw algorithm buttons
        for name, rect in self.buttons.items():
            color = BLUE if (name == self.current_algorithm.value) else GRAY
            pygame.draw.rect(self.screen, color, rect)
            pygame.draw.rect(self.screen, WHITE, rect, 2)
            
            text = self.small_font.render(name, True, WHITE)
            text_rect = text.get_rect(center=rect.center)
            self.screen.blit(text, text_rect)
        
        # Draw instructions
        instructions = [
            "Instructions:",
            "• Left click: Place start/obstacles",
            "• Right click: Place end point",
            "• Select algorithm and click Start",
            "• Clear: Remove path only",
            "• Reset: Clear everything",
            "",
            "Legend:",
            "• Green: Start point",
            "• Red: End point", 
            "• Black: Obstacles",
            "• Light Blue: Visited",
            "• Yellow: Final path"
        ]
        
        y_offset = 250
        for instruction in instructions:
            text = self.small_font.render(instruction, True, WHITE)
            self.screen.blit(text, (820, y_offset))
            y_offset += 20
    
    def draw(self):
        """Main drawing function"""
        self.screen.fill(WHITE)
        self.draw_grid()
        self.draw_ui()
        pygame.display.flip()
    
    def handle_click(self, pos: Tuple[int, int], button: int):
        """Handle mouse clicks on the grid"""
        if self.is_running:
            return
        
        x, y = pos
        
        # Check if click is on grid
        if x >= GRID_WIDTH or y >= GRID_HEIGHT:
            return
        
        col = x // CELL_SIZE
        row = y // CELL_SIZE
        
        if row >= GRID_ROWS or col >= GRID_COLS:
            return
        
        node = self.grid[row][col]
        
        if button == 1:  # Left click
            if not self.start_node and node.cell_type == CellType.EMPTY:
                # Place start node
                node.cell_type = CellType.START
                self.start_node = node
            elif node.cell_type == CellType.EMPTY:
                # Place obstacle
                node.cell_type = CellType.OBSTACLE
            elif node.cell_type == CellType.OBSTACLE:
                # Remove obstacle
                node.cell_type = CellType.EMPTY
        
        elif button == 3:  # Right click
            if not self.end_node and node.cell_type == CellType.EMPTY:
                # Place end node
                node.cell_type = CellType.END
                self.end_node = node
            elif node.cell_type == CellType.END:
                # Remove end node
                node.cell_type = CellType.EMPTY
                self.end_node = None
    
    def handle_button_click(self, pos: Tuple[int, int]):
        """Handle clicks on UI buttons"""
        for name, rect in self.buttons.items():
            if rect.collidepoint(pos):
                if name in ['BFS', 'DFS', 'Dijkstra', 'A*']:
                    self.current_algorithm = Algorithm(name)
                elif name == 'Start':
                    self.run_algorithm()
                elif name == 'Clear':
                    self.clear_path()
                elif name == 'Reset':
                    self.clear_all()
                break
    
    def run(self):
        """Main game loop"""
        running = True
        
        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    pos = pygame.mouse.get_pos()
                    
                    if pos[0] < GRID_WIDTH:
                        # Click on grid
                        self.handle_click(pos, event.button)
                    else:
                        # Click on UI
                        self.handle_button_click(pos)
                
                elif event.type == pygame.KEYDOWN:
                    # Keyboard shortcuts
                    if event.key == pygame.K_SPACE:
                        self.run_algorithm()
                    elif event.key == pygame.K_c:
                        self.clear_path()
                    elif event.key == pygame.K_r:
                        self.clear_all()
                    elif event.key == pygame.K_1:
                        self.current_algorithm = Algorithm.BFS
                    elif event.key == pygame.K_2:
                        self.current_algorithm = Algorithm.DFS
                    elif event.key == pygame.K_3:
                        self.current_algorithm = Algorithm.DIJKSTRA
                    elif event.key == pygame.K_4:
                        self.current_algorithm = Algorithm.ASTAR
            
            self.draw()
            self.clock.tick(60)
        
        pygame.quit()
        sys.exit()

if __name__ == "__main__":
    visualizer = PathfindingVisualizer()
    visualizer.run()
